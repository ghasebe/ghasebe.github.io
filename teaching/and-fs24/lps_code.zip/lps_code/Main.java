import java.io.*;
import java.util.LinkedList;
import java.util.Scanner;
import java.lang.Math;
import java.lang.Integer;
import java.lang.String;

class Main {
    public static void main(String[] args) {

        // Uncomment the following two lines if you want to read from a file
        In.open("public/example.in");
        Out.compareTo("public/example.out");

        int T = In.readInt();               // Read Number of Tasks

        for (int i = 0; i < T; i++) {
            int n = In.readInt();             // Read Length of A

            String SA = In.readString();        // Read A as a string

            char[] A = new char[n];

            for (int j = 0; j < n; j++) {
                A[j] = SA.charAt(j);
            }

            Out.println(Palindrome(A, n));
        }

        // Uncomment the following line if you want to read from a file
        In.close();
    }

    public static int Palindrome(char[] A, int n) {
        // TODO
        return 0;
    }
}
